import logo from './logo.svg';
import './App.css';

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/header/header'
import Main from './components/main/main';
import Teachers from './components/teachers/teachers';
import Shedule from './components/shedule/shedule';
import Contacts from './components/contacts/contacts';
import Log from './components/RegLog/log';
import Reg from './components/RegLog/reg';

function App() {
  return (
    <div className="App">
      <Router>
        <Header/>
        <Routes>
          <Route path='/' element={<Main/>}/>
          <Route path='/login' element={<Log/>}/>
          <Route path='/teachers' element={<Teachers/>}/>
          <Route path='/registration' element={<Reg/>}/>
          <Route path='/teachers' element={<Teachers/>}/>
          <Route path='/shedule' element={<Shedule/>}/>
          <Route path='/contacts' element={<Contacts/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
