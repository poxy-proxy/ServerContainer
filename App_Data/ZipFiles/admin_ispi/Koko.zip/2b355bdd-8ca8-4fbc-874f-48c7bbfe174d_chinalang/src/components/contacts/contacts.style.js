import styled from "styled-components";

export const contactsCont = styled.div`

`;

export const blockOne = styled.div``;