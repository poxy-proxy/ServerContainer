import { Formik, Form, Field, ErrorMessage } from "formik";
import {
  FormContainer,
  FieldContainer,
  StyledField,
  SubmitButton,
} from "../RegLog/forms.style";
import * as Yup from "yup";
import React from "react";
import { useNavigate } from "react-router-dom";

const initialValues = {
  login: '',
  report_text: '',
};

const validationSchema = Yup.object().shape({
  email: Yup.string().email('неверный формат почты').required("почта обязателна"),
  report_text: Yup.string().required("поле обязательно"),
});

const Contacts = () =>{
    const onSubmit = async (values, { setSubmiting, setErrors }) => {
        try {
          
          const response = await fetch("http://localhost:3001/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(values),
          });
          const data = await response.json();
          console.log(data)
          localStorage.setItem("id", data.id);
          console.log(values);
          console.log("отправлено");
          
        } catch (e) {
          console.log(e);
        }
      };
    return(
    <>
        <h1>Телефон</h1>
        <h2>Адрес</h2>
        <h2>Почта</h2>
        <h2>Соц.сети</h2>

        <FormContainer>
      <Formik
      initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit} 
      >
        <Form>
          <FieldContainer>
            <h1>Обратная связь</h1>
            <StyledField type="text" name="email" placeholder="Почта"/>
            <ErrorMessage name='email' component="div"/>
            <StyledField type="text" name="report_text" placeholder='Текст'/>
            <ErrorMessage name='report_text' component="div"/>
            <SubmitButton type="submit">Отправить</SubmitButton>
          </FieldContainer>
          
        </Form>
      </Formik>
    </FormContainer>

    </>

    )
}
export default Contacts