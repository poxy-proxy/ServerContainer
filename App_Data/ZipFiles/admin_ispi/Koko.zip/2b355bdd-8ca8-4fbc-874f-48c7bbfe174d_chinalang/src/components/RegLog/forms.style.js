import { Field } from "formik";
import styled from "styled-components";

export const FormContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap-column: 2vw;
  
  align-items: center;
`;

export const FieldContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap-column: 2vw;
  width: 30vw
  align-items: center;
  border: 0.2vw solid #000000;
  border-radius: 2vw;
  padding: 3vw
`;

export const StyledField = styled(Field)`
  width: 25vw;
  height: 2vw;
  margin-top: 1vw;
  margin-bottom: 1vw;
  border-radius: 0.5vw;
  border: 0.2vw solid #000000;
`;

export const SubmitButton = styled.button`

  margin-top: 1vw;
  margin-bottom: 1vw;
  border-radius: 0.5vw;
  border: 0.2vw solid #000000;
`;

