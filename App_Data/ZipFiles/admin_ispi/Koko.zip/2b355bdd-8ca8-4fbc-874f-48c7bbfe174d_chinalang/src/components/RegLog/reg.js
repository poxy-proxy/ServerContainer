import React, { useState } from 'react';
import { Form, Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { FieldContainer, FormContainer, StyledField, SubmitButton } from './forms.style';

const initialValues = {
  FIO: '',
  login: '',
  password: '',
  email: '',
  phone: '',
};

const validationSchema = Yup.object().shape({
  FIO: Yup.string().required('Поле ФИО обязательно').matches(/^[А-Яа-я\s]+$/, 'Неправильный формат имени'),
  email: Yup.string().email('Неправильный формат почты').required('Поле почты обязательно'),
  login: Yup.string().required('Поле обязательно'),
  password: Yup.string().min(6, 'Пароль должен быть больше 6 символов').required('Поле пароля обязательно'),
  phone: Yup.string().matches(/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/, 'Номер телефона в формате: +7(XXX)-XXX-XX-XX').required('Поле телефона обязательно'),
});

const Reg = () => {
    const [isRegistered, setIsRegistered] = useState(false);

    const onSubmit = async (values, { setSubmitting, setErrors }) => {
      try {
        const response = await fetch('http://localhost:3001/registr', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(values),
        });
  
        const data = await response.json();
  
        if (!response.ok) {
          setIsRegistered(true);
          setErrors(data.errors);
          setSubmitting(false);
          return;
        }
        console.log(values)
        localStorage.setItem('id',data.id)
        console.log('Registration successful:', data);
      } catch (error) {
        console.error('Registration error:', error);
        setSubmitting(false);
      }
    };

  return (
    <FormContainer>
      <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit} >
        <Form>
          <FieldContainer>
          <h1>РЕГИСТРАЦИЯ</h1>
          
            <StyledField type="text" name="FIO" placeholder="ФИО" />
            <ErrorMessage name="FIO" component="div" />
          
          
            <StyledField type="text" name="login" placeholder="Логин" />
            <ErrorMessage name="login" component="div" />
          
          
            <StyledField type="text" name="phone" placeholder="Телефон" />
            <ErrorMessage name="phone" component="div" />
          
          
            <StyledField type="email" name="email" placeholder="Почта" />
            <ErrorMessage name="email" component="div" />
          
          
            <StyledField type="text" name="password" placeholder="Пароль" />
            <ErrorMessage name="password" component="div" />
          
          <SubmitButton type="submit">Зарегистрироваться</SubmitButton>
          </FieldContainer>
        </Form>
      </Formik>
    </FormContainer>
  );
};

export default Reg;
