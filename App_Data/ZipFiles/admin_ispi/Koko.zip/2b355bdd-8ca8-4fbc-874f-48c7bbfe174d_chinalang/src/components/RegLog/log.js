import { Formik, Form, Field, ErrorMessage } from "formik";
import {
  FormContainer,
  FieldContainer,
  StyledField,
  SubmitButton,
} from "./forms.style";
import * as Yup from "yup";
import React from "react";
import { useNavigate } from "react-router-dom";

const initialValues = {
  login: '',
  password: '',
};

const validationSchema = Yup.object().shape({
  login: Yup.string().required("логин обязателен"),
  password: Yup.string().required("пароль обязателен"),
});

const Log = () => {
    const onSubmit = async (values, { setSubmiting, setErrors }) => {
        try {
          if (values.login==='copp' && values.password==='123456')
          {
            const admin = true
            localStorage.setItem('admin',admin)
          }
          else{const response = await fetch("http://localhost:3001/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(values),
          });
          const data = await response.json();
          console.log(data)
          localStorage.setItem("id", data.id);
          
          console.log("авторизация успешна");}
          
        } catch (e) {
          console.log(e);
        }
      };

  return (
    <FormContainer>
      <Formik
      initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit} 
      >
        <Form>
          <FieldContainer>
            <h1>Авторизация</h1>
            <StyledField type="text" name="login" placeholder="Логин"/>
            <ErrorMessage name='login' component="div"/>
            <StyledField type="text" name="password" placeholder='Логин'/>
            <ErrorMessage name='password' component="div"/>
            <SubmitButton type="submit">Авторизация</SubmitButton>
          </FieldContainer>
          
        </Form>
      </Formik>
    </FormContainer>
  );
};
export default Log;
