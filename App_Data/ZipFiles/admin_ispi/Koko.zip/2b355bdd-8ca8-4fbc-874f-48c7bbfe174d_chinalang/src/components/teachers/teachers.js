import { useState, useEffect } from "react"
import { CardContainer } from "../shedule/shedule.style"
import SheduleCard from "../shedule/sheduleCard"

const Teachers = () =>{
    const [data,setData] = useState([])
    useEffect(()=>{
        const fetchTeachers = async () =>{
            try{
                const response = await fetch (`http://localhost:3001/teachers`)
                const teachers = await response.json()
                setData(teachers)
                console.log(teachers)
            }catch(e){
                console.log(e)
            }
        }
        
        fetchTeachers();
    }, [])
    return(
        <>
        <h1>Преподаватели</h1>
        <CardContainer> {data.map(teachers=>(
                <teacheCard
                key={teachers.teach_id}
                name={teachers.name}
                phone = {teachers.phone}

                />
                
            ))}</CardContainer>
       
        </>
    )
}
export default Teachers