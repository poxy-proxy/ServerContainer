import { useEffect } from "react";
import { CardCours } from "./shedule.style";

const TeachersCard = (props) => {
  const {name,phone } = props;

 
  return (
    <CardCours>
      <h1>{name}</h1>
      <h3>{phone}</h3>
    </CardCours>
  );
};
export default TeachersCard;
