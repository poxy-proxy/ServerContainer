import { StyledLink } from "../header/header.style"
import { CreatorCont,CreatorText,CreatorImg, MainButton, MainCont, WelcomeText, WelcomeTextColor, CreatorTextCont } from "./main.style"
import creator from '../../images/1.jpg'
import hiVidio from '../../images/hi.mp4'
const Main = () =>{
    return(
    <MainCont>
        <WelcomeText>Добро пожаловать на курсы <br/>
            <WelcomeTextColor>Китайского</WelcomeTextColor>
           <br/><br/> ХОТИТЕ ЗАПИСАТЬСЯ - ЗАРЕГИСТРИРУЙТЕСЬ
        </WelcomeText>
        
       <StyledLink to={'/registration'}><MainButton>Зарегистрироваться</MainButton></StyledLink>
       <CreatorText>
                    Каждый курс предназначен для определенного уровня знаний:
                    <br/>С - начальный уровень, для тех кто только начал свой путь в изучении 
                    <br/>B - начальный уровень, для тех кто уже имеет общее понимание 
                    <br/>A - продвинутый уровень,для тех кто владеет базовыми знаниями
                </CreatorText>
        <CreatorCont>
            <CreatorTextCont>
                <CreatorText>
                    Наш основатель - Ли Цзянь. Два года назад он <br/>
                    переехал из Чэнду(провинция Сычуань, Китай)<br/>
                    во Владимр для изучения русского языка. <br/>
                     После окончания изучения он решил открыть<br/>
                     нашу школу китайского.
                </CreatorText>
            </CreatorTextCont>
            
            <CreatorImg src={creator}></CreatorImg>
        </CreatorCont>
        <video autoPlay>
            <source src={hiVidio} type="video/mp4"/>
        </video>
    </MainCont>
        
    )
}
export default Main