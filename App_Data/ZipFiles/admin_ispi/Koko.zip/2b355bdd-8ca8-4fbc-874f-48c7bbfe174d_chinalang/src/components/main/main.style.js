import styled from "styled-components";
import { SubmitButton } from "../RegLog/forms.style";

export const MainCont = styled.div`
    margin:1vw;
    display:flex;
    flex-direction:column;
    gap:1vw;
`;

export const WelcomeText = styled.text`
    font-size:3vw;
    font-weight:bold;
`;

export const WelcomeTextColor = styled.text`
font-size:3vw;
font-weight:bold;
text-decoration-color:red;
`;

export const MainButton = styled(SubmitButton)`
    background-color:red;
    font-size:1vw;
    font-weight:bold;
    font-size:2vw;
    text-decoration-color:white;
`;

export const CreatorCont=styled.div`
margin: 1vw;
display: flex;
gap: 1vw;
justify-content: space-between;
align-items: center;
`;

export const CreatorTextCont = styled.div`
width:40vw;
`;

export const CreatorText = styled.text`
font-size:2vw;
font-weight:bold;
`;
export const CreatorImg=styled.img`
width:50vw;
`;