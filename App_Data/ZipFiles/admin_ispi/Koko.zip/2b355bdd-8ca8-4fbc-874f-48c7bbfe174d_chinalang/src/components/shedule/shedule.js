import { useState,useEffect } from "react"
import SheduleCard from "./sheduleCard"
import { CardContainer } from "./shedule.style"

const Shedule = () =>{
    const [courses,setCourses] = useState([])
    useEffect(()=>{
        const fetchCourses = async () =>{
            try{
                const response = await fetch (`http://localhost:3001/courses`)
                const courses = await response.json()
                setCourses(courses)
            }catch(e){
                console.log(e)
            }
        }
        
        fetchCourses();
    }, [])
    

    return(
        <>
            <h1>Расписание</h1>
            <CardContainer>
            {courses.map(course=>(
                <SheduleCard
                key={course.course_id}
                course_id={course.course_id}
                course_name = {course.course_name}
                teacher_name={course.teacher_name}
                auditory={course.auditory}
                time={course.time}
                teacher_phone={course.teacher_phone}
                cost={course.cost}
                />
                
            ))}
        </CardContainer>
        </>
    )
}
export default Shedule