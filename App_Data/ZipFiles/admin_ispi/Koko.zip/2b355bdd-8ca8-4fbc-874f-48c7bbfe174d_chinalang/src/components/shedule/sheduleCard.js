import { useEffect } from "react";
import { CardCours } from "./shedule.style";

const SheduleCard = (props) => {
  const { course_id,course_name, auditory, time,teacher_name, teacher_phone,cost } = props;
   useEffect(()=>{
    const userId = localStorage.getItem('id')

   })
  const GetCoursed = async (course_id)=>{
    try{
        const userId = localStorage.getItem('id')
        const getcoursed = await fetch(`http://localhost:3001/get_coursed/${userId}`,{
            method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(course_id),
        })
        const data = await getcoursed.json();
    }catch(e){console.log(e)}
  }
  return (
    <CardCours>
      <h3>{course_name}</h3>
      <h3>{auditory}</h3>
      <h3>{time}</h3>
      <h3>{teacher_name}</h3>
      <h3>{teacher_phone}</h3>
      <h1>{cost}</h1>
      <button onClick={GetCoursed} >записаться</button>
    </CardCours>
  );
};
export default SheduleCard;
