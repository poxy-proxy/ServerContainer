import styled from "styled-components";

export const CardContainer = styled.div``;
export const CardCours = styled.div`
display:flex;
gap:1vw;
`;