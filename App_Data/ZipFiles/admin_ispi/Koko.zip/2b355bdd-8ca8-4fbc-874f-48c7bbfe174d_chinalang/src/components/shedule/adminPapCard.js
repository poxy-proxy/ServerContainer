import { CardPap } from "./admin.style";

const AdminCard = (props) => {
  const { id, FIO, declaration_text, car_number, status } = props;
    const handleCancel = async () =>{
        try{
            const response = await fetch (`http://localhost:3001/cancel/${id}`,{
                method:'PUT',
                headers:{
                    'Content-Type':'application/json',
                },
                body: JSON.stringify()
            })
            const data = await response.json()
        }catch(e){
            console.log(e)
        }
        
    }

    const handleConfirm = async () =>{
        try{
            const response = await fetch (`http://localhost:3001/confirm/${id}`,{
                method:'PUT',
                headers:{
                    'Content-Type':'application/json',
                },
                body: JSON.stringify()
            })
            const data = await response.json()
        }catch(e){
            console.log(e)
        }
    }

  return (
    <CardPap>
      <h3>{id}</h3>
      <h3>{FIO}</h3>
      <h3>{declaration_text}</h3>
      <h3>{car_number}</h3>
      <h1>{status}</h1>
      <button onClick={handleConfirm}>Подтвердить</button>
      <button onClick={handleCancel}>Отклонить</button>
    </CardPap>
  );
};
export default AdminCard;
