import { Link } from "react-router-dom";
import styled from "styled-components";

export const HeaderCont = styled.div`
    display: flex;
    align-items:center;
    justify-content:center;
    gap:5vw;
    font-size:1.5vw;
    text-decoration:none;
    color: var(--Black, #000);
    height:3vw;
    margin-bottom:1vw;
    margin-top:1vw;
    background-color:yellow;
    padding-top:1vw;
    padding-bottom:1vw;
`;

export const logoCont = styled.div`
    display:flex;
`;

export const Logotipe=styled.img`
width:3vw;
height:3vw;
`;

export const StyledLink = styled(Link)`
    text-decoration:none;
    color: var(--Black, #000);
`;