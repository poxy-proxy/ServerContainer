import React, { useEffect, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { HeaderCont, Logotipe, StyledLink } from "./header.style";

import logotipe from '../../images/logotipe.png'
const Header = ({ isAuth }) => {
  const [isAdmin, setIsAdmin] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const admin = localStorage.getItem('admin');
    console.log(admin)
    if (admin) {
      setIsAdmin(true);
    } else {
      setIsAdmin(false);
    }
  }, []);

  const LogOut = () => {
    localStorage.removeItem('id');
    localStorage.removeItem('admin')
    navigate('/');
  }

  return (
    <HeaderCont>
      <StyledLink to="/">
        
        <h1>CHINALANG</h1>
        
      </StyledLink>
      
      {isAdmin ? (
        <><StyledLink to='/adm'>админка</StyledLink>
        <button onClick={LogOut}>выйти</button></>
        
      ) : (
        <>
          {isAuth ? (
            <>
              
              <StyledLink to="add_pap">Написать заявку</StyledLink>
              <button onClick={LogOut}>выйти</button>
            </>
          ) : (
            <>
              <StyledLink to="shedule">Расписание</StyledLink>
              <StyledLink to="shedule">Расписание</StyledLink>
              <StyledLink to="teachers">Преподаватели</StyledLink>
              <StyledLink to="contacts">Контакты</StyledLink>
              <StyledLink to="/registration">Регистрация</StyledLink>
              <StyledLink to="/login">Вход</StyledLink>
            </>
          )}
        </>
      )}
    </HeaderCont>
  );
};

export default Header;
