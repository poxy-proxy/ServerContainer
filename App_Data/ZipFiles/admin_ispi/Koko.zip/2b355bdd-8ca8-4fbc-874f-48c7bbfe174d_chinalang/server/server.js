const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const knex = require("./db/db");
const { body } = require("express-validator");
const cors = require("cors");

const PORT = 3001;
const app = express();

app.use(cors({ credentials: true, origin: "http://localhost:3000" }));
app.use(express.json());

app.get("/", (req, res) => {
  res.send("<h1> Сервер приложухи </h1>");
});



app.post("/registr", async (req, res) => {
  try {
    const userID = req.body.id;
    const login = req.body.login;
    const existUser = await knex("customers").where({ login }).first();
    if (existUser) {
      return res
        .status(400)
        .json({ error: "пользователь с таким логином уже есть" });
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(req.body.password, salt);
    const user = await knex("customers")
      .insert({
        FIO: req.body.FIO,
        login: req.body.login,
        password: hashedPassword,
        phone: req.body.phone,
        email: req.body.email,
      })
      .returning("*");
    const id = await knex
      .select("id")
      .from("customers")
      .where("login", req.body.login);
    res.cookie("id", id);
    res.cookie("admin", req.body.admin);
    res.status(201).json(user[0]);
  } catch (e) {
    console.log(e);
    res.status(500).json({ error: "фатальная ошибка сервера при регистрации" });
  }
});

app.get("/courses", (req, res) => {
  knex
    .select("*")
    .from("courses")
    .then((courses) => {
      res.json(courses);
      console.log(courses);
    })
    .catch((e) => {
      console.log(e);
    });
});


app.post('/get_coursed/:id', async (req,res)=>{
    try{const userID = req.params.id
    const course = await knex('customercourses').insert({
        customer_id:userID,
        course_id:req.body.course_id,
    })
    .returning("*");
    res.status(201).json(course[0]);

}catch (e) {
        console.log(e);
        res.status(500).json({ error: "фатальная ошибка сервера при регистрации" });}
      
    
})


app.post('/login', async (req,res)=>{
    try{
        const user = await knex.select('*').from('customers').where('login',req.body.login)
        .returning('*')
        console.log(user[0])
        if (!user[0]){
            console.log('пользоватеь не найден')
            return res.status(404).json('пользователь не нанайден')
        }
        const passCompare = await bcrypt.compare(req.body.password,user[0].password)
        if(!passCompare){
            console.log('неверный пароль')
            return res.status(404).json('неверный пароль')
        }
        res.json(user[0])
        res.status(201).json('авторизация успешна')
    }catch(e){
        console.log(e)
        res.status(500).json
    }
})

app.get("/teachers", (req, res) => {
    knex
      .select("*")
      .from("teachers")
      .then((teachers) => {
        res.json(teachers);
        console.log(teachers);
      })
      .catch((e) => {
        console.log(e);
      });
  });

app.post("/auth", async (req, res) => {
  try {
    const user = await knex
      .select("*")
      .from("customers")
      .where("login", req.body.login);
    if (!user[0]) {
      console.log("такого пользователя нет");
      return res.status(404).json("такой пользователь не найден");
    }
    const passCompare = await bcrypt.compare(
      req.body.password,
      user[0].password
    );
    if (!passCompare) {
      console.log("неврный пароль");
      return res.status(404).json("неврный пароль");
    }
    const refreshToken = jwt.sign({ id: userID }, "secret", {
      expiresIn: "3d",
    });
    res.cookie("token", refreshToken);
  } catch (e) {
    console.log(e);
    res.status(500).json({ error: "фатальная ошибка сервера" });
  }
});





app.post('/report', async (req,res)=>{
    try{
        const user = await knex('reports').insert({
            email:req.body.email,
            report_text:req.body.report_text
        })
    }catch(e){
        console.log(e)
        res.status(500).json('фатальная при обратной связи')
    }
} )





app.listen(PORT, () => {
  console.log("сервер работает. Порт = ", PORT);
});
