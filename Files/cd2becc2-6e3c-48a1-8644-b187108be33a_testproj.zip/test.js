const express = require("express");
const knex = require("knex");

const db = knex({ 
    client: "pg",
    connection: {
        host: "172.20.0.2",
        port: "5432",
        user: "Test2@example.com",
        password: "Test2-2",
        database: "test2db"
    }
});


const app = express();

app.use(async (req, res) => {
    const result = await db("test_table");
    res.send(JSON.stringify(result));
})

app.listen(3000, () => console.log("Server is running on port 3000"))