#!D:\vs projects\ServerContainer\App_Data\Projects\Metelkinsp1@yandex.ru\tutorial\project-django\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
