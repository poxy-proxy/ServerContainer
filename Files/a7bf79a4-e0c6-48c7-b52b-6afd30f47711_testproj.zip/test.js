const express = require("express");
const knex = require("knex");

const db = knex({ 
    client: "pg",
    connection: {
        host: "172.18.0.2",
        port: "5432",
        user: "Test4@example.com",
        password: "Test4-4",
        database: "test2db"
    }
});


const app = express();

app.use(async (req, res) => {
    const result = await db("test_table");
    res.send(JSON.stringify(result));
})

app.listen(3000, () => console.log("Server is running on port 3000"))